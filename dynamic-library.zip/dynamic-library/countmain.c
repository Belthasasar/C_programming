#include"count.h"
int main()
{
	count();
	return 0;
}
