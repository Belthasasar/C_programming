#include"cube.h"
int main()
{
	cube();
	return 0;
}
