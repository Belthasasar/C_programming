#include"year.h"
int main()
{
	year();
	return 0;
}
