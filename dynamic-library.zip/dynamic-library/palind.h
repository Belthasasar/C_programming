void palind(void);

