void seclar(void);
