#include"same.h"
int main()
{
	same();
	return 0;
}
