void rev(void);
