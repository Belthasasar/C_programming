#include"large.h"
int main()
{
	lg();
	return 0;
}
