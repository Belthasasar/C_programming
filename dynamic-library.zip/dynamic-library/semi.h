int semi(int val){
}

