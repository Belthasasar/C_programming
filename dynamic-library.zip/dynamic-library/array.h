void arithmedic(void);
