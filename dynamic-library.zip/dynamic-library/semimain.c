#include"semi.h"
int main(void)
{
	semi(){}
}
