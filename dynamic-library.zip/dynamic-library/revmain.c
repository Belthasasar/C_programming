#include"rev.h"
int main()
{
	rev();
	return 0;
}
