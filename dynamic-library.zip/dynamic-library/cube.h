void cube(void);
