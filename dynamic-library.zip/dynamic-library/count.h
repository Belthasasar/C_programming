void count(void);
