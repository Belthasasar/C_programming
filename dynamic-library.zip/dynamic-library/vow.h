void vow(void);

