#include<stdio.h>

int main()
{
        int a[6]={6,9,12,18,24,30};
        int i=0,j=0,res=0,k=0,h=2;
        int b[9];
	int *p,*q;

	p=a;
	q=b;

        while(q<&b[9])
        {
                res=h*3;
                *q=res;
                q++;
                h++;
        }

	q=b;


        while(q<&b[9])
        {

                if(*p==*q)
                {
                        p++;
                }
                else
                {
                        printf("missing %d\n",*q);


                }

              q++;

        }
        return 0;

}


