#include<stdio.h>

int main()
{
        int a[6]={6,9,12,18,24,30};
        int i=0,j=0,res=0,k=0,h=2;
        int b[9];

	while(k<9)
	{
		res=h*3;
		b[k]=res;
		k++;
		h++;
	}



        while(j<9)
        {

                if(i<6 && a[i]==b[j])
                {
                        i++;
                }
                else
                {
                        printf("missing %d\n",b[j]);


                }

              j++;

        }
	return 0;

}

