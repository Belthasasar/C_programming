#include<stdio.h>
#include<string.h>

void main()
{
        char a[10];
        printf("enter the string\n");

        scanf("%s",a);

        int i=0;
        int len=strlen(a);

        while(i<len)
        {
                if((a[i]>='a' && a[i]<='z')||(a[i]>='A'&&a[i]<='Z'))
		{
                	printf("%c",a[i]);
		}
		i++;
        }


}
