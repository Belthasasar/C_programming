#include<stdio.h>
#include<string.h>
int main()
{
	char str[10];
	char rev[10];
	int i=0,j=0;

	printf("enter the string :");
	fgets(str,sizeof(str),stdin);
	str[strcspn(str, "\n")] = '\0';
	int len =strlen(str);
	for(int i=len-1;i>=0;i--)
	{
		rev[j++]=str[i];
	
	}
	rev[j]='\0';
	printf("%s",rev);
	if(strcmp(str,rev)==0)
	{
		printf("it is palindrome\n");
	}
	else
		printf("not");
	return 0;
}


