#include<stdio.h>

int main()
{
	int a=10,*p;

	p=&a;
	*p=100;

	printf("%d",a);

	return 0;
}

	
