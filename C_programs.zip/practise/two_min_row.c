#include<stdio.h>
void display(int x[2][3]);
int main()
{
        int arr[2][3]={{10,20,30},{40,50,60}};
        display(8);
}

void display(int x[2][3])
{
        int cols=3;
	int row=sizeof(x)/sizeof(x[0]);

        for(int i=0;i<row;i++)
        {
                for(int j=0;j<cols;j++)
                {
                        printf("%d\t",x[i][j]);
                }
                printf("\n");
        }
}

