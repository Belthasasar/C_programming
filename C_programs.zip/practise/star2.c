#include<stdio.h>

int main()
{
        int rows = 4;

        for(int i=rows;i>=0;i--)
    		{

			for(int j=0;j<=i;j++)
			{
				if(i<2)
                		{
		
                        		printf("*");
                		}
		
				else
				{
				
					printf("a");
					
				}	
			}
		}
                printf("\n");

        
        return 0;
}


