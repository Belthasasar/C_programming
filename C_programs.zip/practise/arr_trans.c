#include<stdio.h>

int main()
{
	int n,m;


	printf("enter the sizes");

	scanf("%d",&n);
	scanf("%d",&m);

	int i=0,j=0;
	int a[n][m];

	while(i<n)
	{
		j=0;
		while(j<m)
		{
			scanf("%d",&a[i][j]);
			j++;

		}
		i++;
	}
	i=0;
	int trans[m][n];
	while(i<n)
        {
                j=0;
                while(j<m)
		{
			trans[j][i]=a[i][j];
			j++;
		}
		i++;
	}
	i=0;
        while(i<n)
        {
                j=0;
                while(j<m)
                {
                        printf("%d\t",a[i][j]);
                        j++;

                }
		printf("\n");
                i++;
        }
	printf("\n");
	i=0;
	while(i<m)
        {
                j=0;
                while(j<n)
                {
                       printf("%d\t",trans[i][j]);
                        j++;

		}
		printf("\n");
                i++;
        }

	return 0;
}


