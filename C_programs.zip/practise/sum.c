#include<stdio.h>

int main()
{
	int a=6,b=3,c=0;

	c=a|b;
	c=2<<1;

	printf("%d\n",c);

        c=a^b;

        printf("%d",c);

	return 0;
}
