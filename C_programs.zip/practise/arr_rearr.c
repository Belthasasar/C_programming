#include<stdio.h>

int main()
{
	int a[]={1,3,4,5,6,7};

	int len=sizeof(a)/sizeof(int);

	int j=len-1;

	int i=0;

	while(i<=j)
	{
		printf("%d\n",a[i]);
		if(i!=j)
		{

			printf("%d\n",a[j]);
		}
		
		i++;
		j--;
	}
	return 0;
}
