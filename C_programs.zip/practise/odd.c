#include <stdio.h>

int main()
{
	int m;
	scanf("%d",&m);

	if(m & 1)
	{
		printf("odd");

	}
	else
	printf("even");

	return 0;
}
