#include<stdio.h>

int main()
{
	float arr[4]={1.4,2.5,5.9,2.4};

	float *p;

	p=arr;

	int res;

	while(p<&arr[4])
	{
		res=*p/1;

		printf("%d\n",res);
		p++;

	}
	return 0;
}

