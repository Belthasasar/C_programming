#include <stdio.h>

int palinum(int n);

int palinum(int n)
{
	int remainder,rev=0;
	while (n!=0)
	{
		remainder=n%10;
		rev=rev*10+remainder;
		n=n/10;
	}
	printf("%d",rev);
	return rev;
}

int main()
{
	int n;
	scanf("%d",&n);
	int sum=palinum(n);
	if(n==sum)
	{
		printf("yes");
	}
	else 
	printf("no");
}
		
	  	
