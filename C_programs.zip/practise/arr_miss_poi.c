#include<stdio.h>

int main()
{
        int a[11]={1,2,3,4,5,6,8,9,10,11,12};


        int i=0,sum=0,n=12,*p;
        int result=n*(n+1)/2;
	p=a;

        while(i<11)
        {
                sum = sum+*(p+i);
                i++;

        }

        int miss =0;
        miss=result-sum;

        printf("%d",miss);
        return 0;
}

