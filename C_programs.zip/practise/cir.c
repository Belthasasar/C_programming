#include<stdio.h>

int main()
{
        double r,area=0;

        printf("enter the r value");

        scanf(" %lf",&r);

        area=3.14*r*r;

        printf(" area is %lf",area);
}


