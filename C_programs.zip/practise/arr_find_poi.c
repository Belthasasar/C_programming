#include<stdio.h>

int main()
{
	int a[6]={1,2,3,4,5};

	int n;

	int *p;

	printf("enter the search value :");

	scanf("%d",&n);

	p=a;

	while(p<&a[5])
	{

		if(n==*p)
		{
			printf("the value is index position is %ld",p-a);
			break;	
		}
		p++;
	}
	if(p==&a[5])
	{
		printf("not found");
	}

	return 0;
}


