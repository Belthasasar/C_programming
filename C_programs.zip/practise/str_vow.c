#include<stdio.h>
#include<string.h>

int main()
{
	char a[10];

	scanf("%s",a);

	int i=0 ,vcount=0 ,acount=0,ncount=0,len=strlen(a);

	while(i<len)
	{
		if(a[i]=='a'||a[i]=='e'||a[i]=='i'||a[i]=='o'||a[i]=='u'||a[i]=='A'||a[i]=='E'||a[i]=='I'||a[i]=='O'||a[i]=='U')
		{
			vcount++;
		}
		else if(a[i]>'0' && a[i]<'9')
		{
			ncount++;
		}
		else
		{
			acount++;
		}
		i++;
	}
		printf("voewls count is %d\n",vcount);
		printf("alphabets count is %d\n",acount);
		printf("num count is %d\n",ncount);
		return 0;
}

