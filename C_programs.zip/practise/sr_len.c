#include<stdio.h>

int main()
{
	char *a[3];

	int len=sizeof(a)/sizeof(a[0]);

	printf("%d",len);

}
