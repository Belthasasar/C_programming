#include<stdio.h>

int main()
{
	int a[4]={1,2,3,4};

	int i = 0,*p;
	p=a;

	int len=sizeof(a) / sizeof(int);

	//printf("%d\n",len);

	while(i<4)
	{
		printf("%d\n",*(p+i));
	/*	printf("%d\n",*(a+i));
		printf("%d\n",*p);
		p++;
		printf("%p\n",&a[i]);
		printf("%p\n",a);
		a+i;*/

		i++;
	}
	return 0;
}
