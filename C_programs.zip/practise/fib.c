#include<stdio.h>
 
int fibo(int n);

int fibo(int n)
{
	int a=0, b=1,sum=0;
	for(int i=0;i<=n;i++)
	{
		sum =a+b;
		printf("%d\t",sum);

		a=b;
		b=sum;
	}
}

int main()
{
	int n=10;

	fibo(n);

	return 0;
}

		
