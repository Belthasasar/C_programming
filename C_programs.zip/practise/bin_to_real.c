#include<stdio.h>
#include<string.h>

int main()
{
	char str[10];

	printf("enter the binary number");

	scanf("%s",str);

	int len=strlen(str);

	int i=len-1,sum=0,pow=1;

	while(i>=0)
	{
		int num=str[i]-'0';

		sum = sum+num*pow;

		pow=pow*2;

		i--;

	}
	printf("real num is %d",sum);
	return 0;
}

