#include<stdio.h>

int main()
{
        int a[4]={1,2,3,4};
        
        int g=0 ,i=3;
	int temp=0;

       

        while(g<i)
        {
		temp=a[i];

		a[i]=a[g];

		a[g]=temp;


                printf("%d \n",a[g]);

		g++;
		i--;
                
                
        }
        return 0;
}


