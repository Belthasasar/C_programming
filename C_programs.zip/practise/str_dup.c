#include<stdio.h>
#include<string.h>

void main()
{
	char a[10];
	printf("enter the string\n");

	scanf("%s",a);

	int i=0,j=0,count=0;
	int len=strlen(a);

	while(i<len)
	{
		count=0;
		j=0;
	
		
		while(j<len)
		{	
			if(a[j]==a[i])
			{
				count++;
			}
			j++;
		}
		printf("%c is presenting %d times\n",a[i],count);
		i++;
	}


}
	
