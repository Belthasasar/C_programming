#include<stdio.h>
int main()
{
int num = 8;
printf ("%d %d", num << 1, num >> 1);
return 0;
}
