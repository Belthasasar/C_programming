#include<stdio.h>

int arradd(int a[5])
{
	

	int *p;
	int sum=0;
	p=a;

	while(p<a+5)
	{
		sum=sum+*p;
		p++;
	}
	return sum;
}

int main()
{
	int (*array)(int [5]);

	int a[5]={1,2,3,4,5};

	array = arradd;

        int result=array(a);

	printf("%d",result);

	return 0;

}

