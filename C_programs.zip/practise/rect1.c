#include<stdio.h>

int main()
{
        int l,w,area=0;

        printf("enter the length and width");

        scanf(" %d %d",&l,&w);

        area=2*l*w;

        printf(" perimeter is %d",area);
}

