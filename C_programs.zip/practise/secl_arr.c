#include<stdio.h>

int main()
{
        int a[6]={1,7,2,3,4,2};

        int i=0,j=0;

        while(i<6)
        
	{
		j=i+1;	

		
		while(j<6)
		{

			if(a[i]>a[j])
			{
				int temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			j++;
		}
		
		i++;
	}
	i=0;
	while(i<6)
        {
                printf("%d\n",a[i]);
		i++;
        }
	int res=a[i-2];
	printf("%d\n",res);

        return 0;
}

