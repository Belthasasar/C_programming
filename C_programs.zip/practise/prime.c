#include<stdio.h>

int main() 
{
    int a = 20, b = 40, c=2, i = 9;

    while (a <= b) 
    {
        c = 2;
        int prime = 1;

        while (c <= i) 
	{
            if (a % c == 0) 
	    {
                prime = 0;
		break;
            }
	    
	    
            
		c++;
	    
        }

        if (prime == 1)
            printf("%d is a prime number\n", a);
        else
            printf("%d is not a prime number\n", a);

        a++;
    }

    return 0;
}

