#include<stdio.h>

int main()
{
        int b,h,area=0;

        printf("enter the bash and height");

        scanf(" %d %d",&b,&h);

        area=0.5*b*h;

        printf("area is %d",area);
}


