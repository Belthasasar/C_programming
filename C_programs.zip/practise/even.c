#include<stdio.h>

int main()
{
	int n=20,ev=0;
	
	while(ev<=n)
	{
		printf("%d\n",ev);
		ev=ev+2;
	
	}

	ev=1;
	while(ev<=n)
        {
	        printf("%d\n",ev);
                ev=ev+2;

        }
	return 0;
}



