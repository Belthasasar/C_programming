#include<stdio.h>

int main()
{
	int a[6]={7,2,1,3,4,2};

	int i=0,n=a[0];

	while(i<6)
	{
		
		if(a[i]<n)
		{
			n=a[i];
		}
					
		i++;
	}
	printf("%d",n);
	return 0;
}
