#include<stdio.h>
int main(){
int i = 16;
i =! i > 18;
printf("i = %d",i);
return 0;
}
