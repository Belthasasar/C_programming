#include<stdio.h>

int main()
{
        int n=20,ev=10,ev1=ev;

        while(ev<=n)
        {
                printf("%d\n",ev);
                ev=ev+2;

        }

        ev=ev1+1;
        while(ev<=n)
        {
                printf("%d\n",ev);
                ev=ev+2;

        }
        return 0;
}



