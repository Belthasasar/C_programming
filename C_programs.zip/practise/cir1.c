#include<stdio.h>

int main()
{
        double r,area=0;

        printf("enter the r value");

        scanf(" %lf",&r);

        area=2*3.14*r;

        printf(" perimeter is %lf",area);
}


