#include<stdio.h>
void display(int (*x)[3],int rows);
void display(int (*x)[3],int rows)
{
	int col=3;
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<col;j++)
		{
			printf("%d",x[i][j]);
		}
		printf("\n");
	}
}

int main()
{
	 int rows,col;

	 scanf("%d",&rows);
	 scanf("%d",&col);

         int arr[rows][col]={{1,2,3,},{1,2,3},{1,2,3}};

         display(arr,rows);

	return 0;

}


