#include<stdio.h>

void main()
{
	int a[2][3]={{10,20,30},{40,50,60}};
//	int i=0,j=0;
/*	while(i<2)
	{
		printf("%p\n",&a[i]);
		i++;
	}*/
	 printf("%p\n",&a);
	 printf("%p\n",&a[0]);
	 printf("%p\n",*a);
	 printf("%p\n",a+1);
	 printf("%p\n",a+1);
	 printf("%d\n",**(a+1));
	 printf("%p\n",*(a+2));


}


	

