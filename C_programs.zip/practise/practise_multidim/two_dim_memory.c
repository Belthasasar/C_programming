
#include<stdio.h>

int main()

{
	char (*p)[6];

	char arr[6]="sasar";

	p = &arr;

	printf("%c\n",*(*(p+0)+3));
	printf("%s\n",*((p+0)+0));
	printf("%s\n",(*(p+0)+1));
	return 0;

}

