#include<stdio.h>

int main()
{
        int a[4]={1,2,3,4};
	int b[4];
 

        int len=sizeof(a) / sizeof(int);

	int i = len-1;
	int g=0;

        printf("%d\n",len);

        while(i>=0)
        {
		b[g]=a[i];

                printf("%d\n",b[g]);
		g++;
                i--;
        }
        return 0;
}

