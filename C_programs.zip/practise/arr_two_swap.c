#include<stdio.h>

int main()
{
        int a[5]={1,2,3,4,5};

        int temp[2];

        temp[0]=a[2];

        a[2]=a[0];

        a[0]=temp[0];

	temp[1]=a[3];

        a[3]=a[1];

        a[1]=temp[1];



        int i=0;

        while(i<5)
        {
                printf("%d\n",a[i]);
                i++;
        }
        return 0;
}

