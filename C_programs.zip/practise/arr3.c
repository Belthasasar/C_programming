#include<stdio.h>

int arrayss(int size ,int arr[size]);

int arrayss(int size,int arr[size])
{
	int count=0;
	for(int i=0;i<size;i++)
	{
		count =0;
	        for(int j=0;j<size;j++)
		{
			if(arr[i]==arr[j])
			{
				count++;
			}
		
		}

	   //printf("the element %d is comes %d times\n",arr[i],count);

	   if(count>1)
	   {
		   printf("the dup is %d\n",arr[i]);
	   }

	}

}

int main()
{
	int size=4,arr[size];

	for(int i=0;i<size;i++)
	{
		scanf("%d",arr+i);
	}

	arrayss(size,arr);

	return 0;
}


