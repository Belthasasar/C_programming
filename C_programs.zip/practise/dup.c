#include <stdio.h>

void array(int n);
void array(int n)
{
	int a[n],j;

	for(int i=0;i<n;i++)
	{
	scanf("%d",&a[i]);
	}
	printf("\n");
        printf("after removing\n");

	for(int i=0;i<n;i++)
	{
	        for(j=0;j<i;j++)
		{
			if(a[i]==a[j])
			{
				break;
			}
			
		}
		if(i==j)
			{
				printf("%d\n",a[i]);
			}
	
	}
}
int main()
{
	int a=5;
	array(a);
	return 0;
}

