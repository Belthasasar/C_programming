#include<stdio.h>
int main()
{
int i = 5;
int a = ++i + ++i;
printf("%d",a);
return 0;
}
