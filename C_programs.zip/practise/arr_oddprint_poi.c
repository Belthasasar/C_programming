#include<stdio.h>

int main()
{
        int a[11]={1,2,3,4,5,5,4,8,2,1};

        int *p;

        p=a;

        while(p<&a[11])
        {
                if(*p%2==0)
                {
                        
                }
                else
                {
                        printf("%d\n",*p);
                }
                p++;
        }
               

        return 0;
}

