#include<stdio.h>

int main()

{
	const int a=10;

	int *p,*q;

	p=&a;

	p=q;

	*q=100;

	printf("%d",a);

	return 0;

}
