#include<stdio.h>

void strre();

void strre()
{
	char str[10];
	int length=0;

	printf("enter the string\n");
	fgets(str,sizeof(str),stdin);

	for(int i=0; str[i]!='\0';i++)
	{
		length++;
	}
	printf("the length is %d\n",length);

	for(int i=length-1;i>=0;i--)
	{
		printf("%c",str[i]);
	}

}
int main()
{
	strre();
	return 0;
}
