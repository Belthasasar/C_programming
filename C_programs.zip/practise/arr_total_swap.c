#include<stdio.h>

int main()
{
	int a[5]={1,2,3,4,5};

	int i=4;

	while(i>=0)
	{
		printf("%d",a[i]);
		i--;
	}
	return 0;
}

