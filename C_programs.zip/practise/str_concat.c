#include<stdio.h>
#include<string.h>

int main()
{
	char a[17]="hello";

	char b[7]=" world";

	int i=strlen(a),j=0;

	while(b[j] !='\0')
	{
		a[i]=b[j];

		i++;
		j++;
	}


	printf("%s\n",a);

	return 0;

}


