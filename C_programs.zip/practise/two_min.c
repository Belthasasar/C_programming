#include<stdio.h>
void display(int (*x)[3],int);
int main()
{
	int arr[2][3]={{10,20,30},{40,50,60}};
	int row=sizeof(arr)/sizeof(arr[0]);
	printf("%d\n",row);
	display(arr,row);
}

void display(int (*x)[3],int rows)
{
	int cols=3;
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<cols;j++)
		{
			printf("%d\t",x[i][j]);
		}
		printf("\n");
	}
}
