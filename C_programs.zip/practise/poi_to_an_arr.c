#include <stdio.h>

int main() 
{
    
    int arr[2][3] = { {1, 2, 3}, {4, 5, 6} };

    int (*p)[3] = arr;

    printf("%d\n", p[1][0]); 

    return 0;
}

