#include<stdio.h>

void arrmul(int a[],int b[])
{
	int c[4];

	int i=0,j=0,k=0;
	int len=4;

	while(i<len)
	{
		c[j]=a[i]*b[k];

		i++;
		k++;
		j++;
	}
	j=0;
	printf("result\n");
	while(j<len)
	{
		printf("%d \n",c[j]);
		j++;
	}
}

int main()
{
	int a[4];

	int b[4];

	int i=0,j=0,len=4;

	while(i<len)
	{

	scanf("%d",&a[i]);
	i++;
	}
 	while(j<len)
        {
        
        scanf("%d",&b[j]);
        j++;
        }

	arrmul(a,b);

	return 0;
}
	

