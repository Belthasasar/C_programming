#include<stdio.h>
#include<string.h>

int main()
{
	char str[6]="madam";

	char rev[6];

	char *p,*q;


	p=&str[4];
	q=rev;

	while(p>=&str[0])

	{
		*q=*p;

		q++;

		p--;
	
	}
	

	if(strcmp(str,rev)==0)
	{
		printf("palind");

	}
	else
	{
		printf("not palind");
	}
	return 0;
}
