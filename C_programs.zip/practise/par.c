#include<stdio.h>

int main()
{
        int b,h,area=0;

        printf("enter the bash and height");

        scanf(" %d %d",&b,&h);

        area=b*h;

        printf("area is %d",area);
}


