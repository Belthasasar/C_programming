#include<stdio.h>

int main()
{
        int a[11]={6,7,8,9,11,13,15,16};
        int res=0,i=0,st=6,limit=17;

        while(st<=limit)
        {

                if(i<11 && a[i]==st)
		{
			i++;
		}
		else
                {
                        printf("missing %d\n",st);
			
		
		}

              st++;
	    
        }
}



