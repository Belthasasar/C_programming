#include <stdio.h>

int main() {
    int a[8] = {5, 3, 24, 21, 6, 7, 2, 1};
    int i, j, temp;

    for (i = 0; i < 8 ; i++) 
    {
        for (j = 0; j <7 - i; j++) 
	{
            if (a[j] > a[j + 1]) 
	    {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }

    for (i = 0; i < 8; i++) 
    {
        
	if(i==6)
	{

		printf("sec lar %d",a[i]);
    	}
        printf("%d\n", a[i]);

    }
    
	
    

    return 0;
}

