#include<stdio.h>

int main()
{
        int a[8]={6,7,8,9,11,13,15,16};
        int i=0,j=0;
        int b[11]={6,7,8,9,10,11,12,13,14,15,16};
	int *p,*q;
	p=a;
	q=b;

        while(q<&b[11])
        {

                if(*p==*q)
                {
                      
			p++;
			
                }
                else
                {
                        printf("missing %d\n",*q);


                }

              q++;
	      

        }

}


