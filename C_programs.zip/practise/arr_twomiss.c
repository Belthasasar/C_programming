#include<stdio.h>

int main()
{
	int a[10]={7,8,9,10,11,13,14,15,16,17};
	int res=0,i=0;
	while(i<10)
	{

		res=a[i]-i;
		if(res != 7)
		{
			printf("missing %d",i+7);
			break;
		
			
		}
		i++;
	
	}
}




