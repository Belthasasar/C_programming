#include<stdio.h>

int main()

{
	char name[5];

	int i=0,count=0;

	scanf("%s",&name);
	printf("%s\n",name);

	while(name [i] !='\0')
	{
		count++;
		i++;	
	}
	printf("%d",count);
	printf("\n");
	i=count-1;

	while(i>=0)
        {
        printf("%c",name[i]);

        i--;
        }


}
