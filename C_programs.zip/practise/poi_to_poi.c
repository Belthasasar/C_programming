#include<stdio.h>

int main()
{
	int a=10,*p,*q,*r;

	p=&a;

	q=p;

	r=q;

	*r=1000;

	printf("%d",a);

	return 0;

}
