#include<stdio.h>

int main()

{
        int a[8]={5,3,1,4,9,7,8,2},*p;

        p=a;
        int i=0,temp;
        int len=sizeof(a)/sizeof(int);

        while(p<&a[8])
        {
                i=1;
                while(i<8-(p-a))
                {
                        if(*p<*(p+i))
                        {
                                temp=*(p+i);
                                *(p+i)=*p;
                                *p=temp;


                        }
                        i++;

                }
                p++;
        }

        p=a;
        while(p<&a[8])
        {
                printf("%d\n",*p);

                p++;
        }
        p=a;

        int seclar=*(p+len-2);
        printf("%d seclar\n",seclar);




        return 0;


}

