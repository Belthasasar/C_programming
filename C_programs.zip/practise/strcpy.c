#include<stdio.h>

int main()
{
	char a[10];

	scanf("%s",a);

	char b[10];

	int i=0,j=0;

	while(a[i] !='\0')
	{
		b[j]=a[i];
		i++;
		j++;
	}
	b[j]='\0';
	printf("copy string is %s\n",b);
	return 0;
}



