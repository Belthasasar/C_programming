#include<stdio.h>

int main()
{
	int a[5]={1,2,3,4,5};

	int temp=0;

	temp=a[2];

	a[2]=a[0];

	a[0]=temp;

	int i=0;

	while(i<5)
	{
		printf("%d\n",a[i]);
		i++;
	}
	printf("\n");
	i=4;
	while(i>=0)
	{
		printf("%d\n",a[i]);
                i--;
	}

	return 0;
}
