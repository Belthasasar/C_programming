#include<stdio.h>

int main()
{
	int n=10,i=1,res=0;

	for(i=1;i<=n;i++)
	{
	        for(int j=1;j<=n;j++)
		{
			res=j*i;

			printf("%d*%d=%d\n",j,i,res);

		}
		printf("\n");
	}
	return 0;
}


