#include<stdio.h>

int main()
{
        int a[8]={2,3,4,1,5,6,7,8};
        int *p,max;
        p=a;
        int len = sizeof(a)/sizeof(int);

        int sum=0 , avg=0,min;

	max=*p;
	min=*p;



        while(p<&a[8])
        {
                sum=sum+*p;
                p++;
        }
        avg=sum/len;

        printf("sum  %d",sum);
        printf("avg  %d\n",avg);

        p=a;
       

        while(p<&a[len])
        {
	

                if(*p>max)
                {
			max=*p;
                        
			
                }
                p++;

        }
	printf("max is %d\n",max);
	p=a;
	while(p<&a[len])
        {


                if(*p<min)
                {
                        min=*p;


                }
                p++;

        }
        printf("min %d\n",min);



	return 0;
}
