#include<stdio.h>

int main()
{
        int a,area=0;

        printf("enter the a value");

        scanf(" %d",&a);

        area=4*a;

        printf(" perimeter is %d",area);
}
       
