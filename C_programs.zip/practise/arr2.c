#include<stdio.h>

int main()
{
	int a[5]={1,2,3,4,5};
	int luc=4;

	for(int i=0;i<5;i++)
	{
		if(luc==a[i])
		{
			printf("lucky num is position %d ",i);
		}
	}
	return 0;
}
