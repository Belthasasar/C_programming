#include<stdio.h>

void hello();

int main()
{
	void (*fp)();

	fp=hello;

	(*fp)();
	fp();

}

void hello()
{
	printf("hello");

}
