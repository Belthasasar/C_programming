#include<stdio.h>
#include <string.h>

int main()

{
	char str[10];

	printf("enter the string");

	scanf("%s",&str);

	int len=strlen(str);

	char *a;
	int count=0;
	a=str;

	while(a<&str[len])
	{
		count++;
		a++;

	}
	printf("%d",count);

	return 0;

}


