#include<stdio.h>

int main()

{
	int *p,*a;

	int b=10;

	p=&b;

	a=&b;

	printf("%d\n %d\n",*p,*a);

	*p=30;

	printf("%d \n %d",*p,*a);
	return 0;
}







