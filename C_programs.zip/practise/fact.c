#include<stdio.h>

int fact(int n);

int fact(int n)
{
	int fact = 1;
	for(int i=1;i<=n;i++)
	{
		fact=fact * i;
 		printf("%d is factorial %d\n",i,fact);

	}

}

int main()
{
	int n=5;
	fact(n);

	
	
}
