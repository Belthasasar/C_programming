#include <stdio.h>

int main()
{
	int *ptr;
	int a=10;

	ptr=&a;

	printf("%p\n",ptr);
	printf("%p\n",&a);
	printf("%p\n",&ptr);
	printf("a is value %d\n",a);
	printf("value of that adress %d\n",*ptr);


}

