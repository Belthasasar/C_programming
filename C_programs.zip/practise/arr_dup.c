#include<stdio.h>

int main()
{
	int a[10]={3,8,6,8,10,12,15,15,5,20};

	int i=0;
	int j=0;

	while(i<10)
	{
//		j=0;
	
		while(j<i)
		{
			if(a[i]==a[j])
			{
				printf("%d dup value \n",a[i]);
			}
			j++;
		}
		i++;
	}
	return 0;
}
		
