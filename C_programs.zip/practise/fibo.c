#include<stdio.h>
int main()
{
	int a=0,b=1,c=0,n=10;

	printf("%d\t%d\t",a,b);

	for(int i=0;i<=n;i++)
	{
		c=a+b;

		printf("%d\t",c);

		a=b;
		b=c;
	}
	return 0;
}
