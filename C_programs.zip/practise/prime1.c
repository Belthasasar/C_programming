#include<stdio.h>

int main()
{
	int a=20,b=60;

	int i = 2,prime=1;

	while(a<=b)
	{
		i=2;
		while(i<9)
		{
			if(a%i==0)
			{
				printf("%d is not prime\n",a);
				prime=0;
				break;
			}
			
			
			i++;

		}

		
		a++;
	}
	return 0;
}
