#include<stdio.h>

int main()
{
        int b,h,area=0;

        printf("enter the bash and height");

        scanf(" %d %d",&b,&h);

        area=2*b*h;

        printf("perimeter is %d",area);
}


