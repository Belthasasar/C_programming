#include<stdio.h>

int main()
{
        int a[11]={1,2,3,4,5,5,4,8,2,1};

        int res=0,sum=0,*p;

        p=a;

        while(p<&a[11])
        {
                if(*p%2==0)
                {
                        res=res+*p;
                }
                else
                {
                        sum=sum+*p;
                }
		p++;
	}
                printf("even  %d \n",res);
        
                printf("odd  %d\n",sum);
	 
        return 0;
}


