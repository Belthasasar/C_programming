#include<stdio.h>

int main()
{
        int n=2,ev=4,i=1,m=20,res;

        while(i<m)
        {
		res=i*n;
                printf("%d\n",res);
                res=i*ev;
		printf("%d\n",res);

		i=i+1;
	}
	return 0;
}



