#include<stdio.h>

int even(int a)
{
	if(a%2==0)
	{
		printf("even");
		
	}
	else{
		printf("odd");
		
	}
}

int main()
{
	int (*fun)(int);
	
	fun=even;

	int a=203;

	fun(a);
}
