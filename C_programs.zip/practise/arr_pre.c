#include<stdio.h>

int main()
{
	int a[8]={1,2,3,4,1,3,4,6};
	int count=1,i=7,j=0;

	while(i>=0)
	{
		j=0;
		count=1;
		while(j<i)
		{
			if(a[i]==a[j])
			{
				count++;
			
			}
			
			j++;
					
	 	       
		}
		 printf("%d is presnt %d times\n",a[j],count);
		

		i--;
	}
	return 0;
}

		
