#include<stdio.h>

int main()
{
	int l,w,area=0;

	printf("enter the length and width");

	scanf(" %d %d",&l,&w);

	area=l*w;

	printf(" area is %d",area);
}
