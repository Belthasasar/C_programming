#include"swapping.h"
int main()
{
	swapp();
	return 0;
}

