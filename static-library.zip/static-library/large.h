void lg(void);
