int semi(int val);

