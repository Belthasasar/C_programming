#include"equal.h"
int main()
{
	equal();
	return 0;
}

