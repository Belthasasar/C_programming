void same(void);

