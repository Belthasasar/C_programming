#include"even.h"
int main()
{
	even();
	return 0;
}
