void equal(void);

