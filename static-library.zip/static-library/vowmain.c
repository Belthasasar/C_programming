#include"vow.h"
int main()
{
	vow();
	return 0;
}

