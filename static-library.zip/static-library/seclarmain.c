#include"seclar.h"
int main()
{
	seclar();
	return 0;
}
