#include"array.h"
int main()
{
	arithmedic();
 	return 0;
}
