#include"upper.h"
int main()
{
	upper();
	return 0;
}
