#include <stdio.h> 
#define N 10 
  
int semi(int val) 
{ 
    if (val <= N && printf("%d ", val) && semi(val + 1)) { 
    } 
}
