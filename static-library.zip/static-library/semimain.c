#include"semi.h"
int main()
{
	semi();
	return 0;
}
