#include"palind.h"
int main()
{
	palind();
	return 0;
}
